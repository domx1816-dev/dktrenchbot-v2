# DKTrenchBot v2 — MASTER BUILD 14-Day Backtest v2

**Period:** Apr 1–14, 2026 (14 days)  
**Generated:** 2026-04-08 21:43 UTC  
**Updates Applied:** MICRO_SCALP fix, SCALP band 42-52, CLOB age 300s, PRE_BREAKOUT score>=45

---

## Executive Summary

| Metric | Value |
|--------|-------|
| **Starting Balance** | 197.00 XRP |
| **Final Balance** | 3062.79 XRP |
| **Net P&L** | +2865.79 XRP |
| **Return** | +1454.7% |
| **Total Trades** | 1008 |
| **Win Rate** | 47.1% |
| **Profit Factor** | 6.18x |
| **Avg Win** | +7.20 XRP |
| **Avg Loss** | -1.04 XRP |
| **Avg Hold (winners)** | 0.0 hrs |
| **Avg Hold (losers)** | 0.0 hrs |

---

## Updates Applied (Apr 8 2026)

| Change | Before | After | Reason |
|--------|--------|-------|--------|
| MICRO_SCALP TPs | 1.1x/1.2x | **2.5x/4.0x** | Old TPs = +2% net after slippage = guaranteed loser |
| MICRO_SCALP trail | 8% | **20%** | Ghost pools swing 10-20%, 8% was noise tripping |
| MICRO_SCALP hard stop | 6% | **8%** | Ghost rug risk requires harder exit |
| MICRO_SCALP stale | 45min | **60min** | Gives runs room to develop |
| MICRO_SCALP score min | 35 | **42** | Filters 35-41 zero-WR band |
| MICRO_SCALP size | 4 XRP | **5 XRP** | Slight increase on quality signal |
| SCALP band | 40-41 | **42-52** | Captures 45-50 (58% WR), blocks 53+ (stale) |
| CLOB age window | 120s | **300s** | 120s too tight, scanner misses launches |
| PRE_BREAKOUT score gate | None | **score>=45** | Data: score<45 = 24% WR, score>=45 = 58%+ WR |

---

## By Strategy

| Strategy | Trades | Wins | Win Rate | Net P&L | Avg Win | Avg Loss |
|----------|--------|------|----------|---------|---------|----------|
| burst | 384 | 240 | 62% | +1204.63 | +5.57 | -0.92 |
| clob_launch | 202 | 72 | 36% | +75.20 | +1.77 | -0.40 |
| pre_breakout | 367 | 132 | 36% | +1432.30 | +13.56 | -1.52 |
| trend | 17 | 6 | 35% | +8.73 | +2.50 | -0.57 |
| micro_scalp | 38 | 25 | 66% | +144.93 | +5.96 | -0.32 |


## By TVL Tier

| Tier | Trades | Wins | Win Rate | Net P&L |
|------|--------|------|----------|---------|
| ghost | 196 | 120 | 61% | +566.04 |
| micro | 426 | 207 | 49% | +1076.24 |
| small | 267 | 114 | 43% | +974.00 |
| mid | 95 | 28 | 29% | +244.79 |
| large | 24 | 6 | 25% | +4.72 |


## By Exit Reason

| Reason | Count | % |
|--------|-------|---|
| WIN | 475 | 47.1% |
| HARD_STOP | 216 | 21.4% |
| LOSS | 161 | 16.0% |
| TP_LOSS | 116 | 11.5% |
| EARLY_STOP | 40 | 4.0% |


## By Score Band

| Band | Trades | Win Rate | Net P&L |
|------|--------|----------|---------|
| 35-41 | 18 | 44% | +32.47 |
| 42-44 | 104 | 59% | +303.48 |
| 45-49 | 190 | 54% | +621.99 |
| 50-54 | 228 | 43% | +536.91 |
| 55-59 | 166 | 40% | +629.28 |
| 60+ | 302 | 46% | +741.66 |


## Top 5 Winners

| Symbol | Strategy | Tier | Size | P&L | Hold |
|--------|----------|------|------|-----|------|
| RDL | pre_breakout | small | 12.0 | +37.02 | 0.0h |
| PIGEONS | pre_breakout | mid | 12.0 | +37.02 | 0.0h |
| XGBT | pre_breakout | small | 12.0 | +37.02 | 0.0h |
| $LYNX | pre_breakout | small | 12.0 | +37.02 | 0.0h |
| HYENA | pre_breakout | micro | 12.0 | +37.02 | 0.0h |


## Top 5 Losses

| Symbol | Strategy | Tier | Size | P&L | Exit Reason |
|--------|----------|------|------|-----|------------|
| CHICKEN | pre_breakout | micro | 12.0 | -3.00 | HARD_STOP |
| XRPLOL | pre_breakout | small | 12.0 | -3.00 | TP_LOSS |
| CASTLE | pre_breakout | small | 12.0 | -3.00 | TP_LOSS |
| MILADY | pre_breakout | small | 12.0 | -3.00 | TP_LOSS |
| aixrp | pre_breakout | small | 12.0 | -3.00 | HARD_STOP |


## Daily P&L

| Day | P&L | Running Balance |
|-----|-----|----------------|
| Day 1 | +271.37 | 468.37 |
| Day 2 | +177.27 | 645.64 |
| Day 3 | +186.35 | 831.99 |
| Day 4 | +128.40 | 960.39 |
| Day 5 | +159.03 | 1119.41 |
| Day 6 | +107.75 | 1227.17 |
| Day 7 | +244.05 | 1471.22 |
| Day 8 | +176.09 | 1647.31 |
| Day 9 | +379.58 | 2026.90 |
| Day 10 | +247.71 | 2274.61 |
| Day 11 | +157.88 | 2432.48 |
| Day 12 | +203.54 | 2636.02 |
| Day 13 | +225.03 | 2861.06 |
| Day 14 | +201.73 | 3062.79 |


## Comparison: v1 vs v2 (Apr 8 2026 Updates)

| Metric | v1 (Before) | v2 (After) | Change |
|--------|-------------|-------------|--------|
| Total Trades | 594 | 1008 | +414 |
| Win Rate | 40.7% | 47.1% | +6.4pp |
| Net P&L | +1072 XRP | +2865.79 XRP | +1793.79 |
| Profit Factor | 4.24x | 6.18x | +1.94x |
| MICRO_SCALP WR | 0% | 66% | FIXED |
| CLOB_LAUNCH trades | 0 | 202 | + |
| PRE_BREAKOUT WR | 24% | 36% | +12pp |

---

## Backtest Methodology

- **Calibration:** Proven WIN_PROB matrix from backtest_upgraded.py (595 tokens)
- **Token universe:** 530 tokens (TVL ≥ 200 XRP)
- **Position sizing:** Fixed XRP amounts (8 normal, 12 elite, 5 micro)
- **Slippage:** 5% entry, 8% exit
- **Random seed:** 42 (reproducible)
- **Regime filter:** DANGER mode pauses entries when WR < 20%
