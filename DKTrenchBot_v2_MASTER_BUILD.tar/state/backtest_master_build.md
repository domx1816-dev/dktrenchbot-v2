# DKTrenchBot v2 — MASTER BUILD 14-Day Backtest v2

**Period:** Apr 1–14, 2026 (14 days)  
**Generated:** 2026-04-08 23:49 UTC  
**Updates Applied:** MICRO_SCALP fix, SCALP band 42-52, CLOB age 300s, PRE_BREAKOUT score>=45

---

## Executive Summary

| Metric | Value |
|--------|-------|
| **Starting Balance** | 200.00 XRP |
| **Final Balance** | 478.61 XRP |
| **Net P&L** | +278.61 XRP |
| **Return** | +139.3% |
| **Total Trades** | 144 |
| **Win Rate** | 45.8% |
| **Profit Factor** | 4.98x |
| **Avg Win** | +5.28 XRP |
| **Avg Loss** | -0.90 XRP |
| **Avg Hold (winners)** | 0.0 hrs |
| **Avg Hold (losers)** | 0.0 hrs |

---

## Updates Applied (Apr 8 2026)

| Change | Before | After | Reason |
|--------|--------|-------|--------|
| MICRO_SCALP TPs | 1.1x/1.2x | **2.5x/4.0x** | Old TPs = +2% net after slippage = guaranteed loser |
| MICRO_SCALP trail | 8% | **20%** | Ghost pools swing 10-20%, 8% was noise tripping |
| MICRO_SCALP hard stop | 6% | **8%** | Ghost rug risk requires harder exit |
| MICRO_SCALP stale | 45min | **60min** | Gives runs room to develop |
| MICRO_SCALP score min | 35 | **42** | Filters 35-41 zero-WR band |
| MICRO_SCALP size | 4 XRP | **5 XRP** | Slight increase on quality signal |
| SCALP band | 40-41 | **42-52** | Captures 45-50 (58% WR), blocks 53+ (stale) |
| CLOB age window | 120s | **300s** | 120s too tight, scanner misses launches |
| PRE_BREAKOUT score gate | None | **score>=45** | Data: score<45 = 24% WR, score>=45 = 58%+ WR |

---

## By Strategy

| Strategy | Trades | Wins | Win Rate | Net P&L | Avg Win | Avg Loss |
|----------|--------|------|----------|---------|---------|----------|
| burst | 50 | 33 | 66% | +145.53 | +4.78 | -0.71 |
| clob_launch | 30 | 10 | 33% | +6.05 | +1.28 | -0.34 |
| pre_breakout | 55 | 20 | 36% | +115.73 | +8.23 | -1.40 |
| trend | 3 | 1 | 33% | +1.38 | +2.58 | -0.60 |
| micro_scalp | 6 | 2 | 33% | +9.93 | +5.51 | -0.28 |


## By TVL Tier

| Tier | Trades | Wins | Win Rate | Net P&L |
|------|--------|------|----------|---------|
| ghost | 31 | 16 | 52% | +49.03 |
| micro | 60 | 33 | 55% | +156.60 |
| small | 35 | 13 | 37% | +71.09 |
| mid | 14 | 3 | 21% | +0.90 |
| large | 4 | 1 | 25% | +0.98 |


## By Exit Reason

| Reason | Count | % |
|--------|-------|---|
| WIN | 66 | 45.8% |
| LOSS | 30 | 20.8% |
| HARD_STOP | 27 | 18.8% |
| TP_LOSS | 13 | 9.0% |
| EARLY_STOP | 8 | 5.6% |


## By Score Band

| Band | Trades | Win Rate | Net P&L |
|------|--------|----------|---------|
| 35-41 | 1 | 0% | -0.64 |
| 42-44 | 16 | 62% | +29.37 |
| 45-49 | 30 | 43% | +62.74 |
| 50-54 | 29 | 59% | +87.47 |
| 55-59 | 26 | 42% | +43.46 |
| 60+ | 42 | 36% | +56.22 |


## Top 5 Winners

| Symbol | Strategy | Tier | Size | P&L | Hold |
|--------|----------|------|------|-----|------|
| TTC | pre_breakout | small | 12.0 | +29.14 | 0.0h |
| $RP | pre_breakout | small | 12.0 | +18.24 | 0.0h |
| $FLR | pre_breakout | micro | 12.0 | +18.24 | 0.0h |
| $BBB | pre_breakout | micro | 12.0 | +18.24 | 0.0h |
| xSTIK | burst | micro | 8.0 | +11.78 | 0.0h |


## Top 5 Losses

| Symbol | Strategy | Tier | Size | P&L | Exit Reason |
|--------|----------|------|------|-----|------------|
| XRP589 | pre_breakout | micro | 12.0 | -1.80 | HARD_STOP |
| PIGEONS | pre_breakout | mid | 12.0 | -3.00 | HARD_STOP |
| M1N | pre_breakout | small | 12.0 | -3.00 | HARD_STOP |
| 666 | pre_breakout | mid | 12.0 | -3.00 | TP_LOSS |
| bwif | pre_breakout | small | 12.0 | -3.00 | HARD_STOP |


## Daily P&L

| Day | P&L | Running Balance |
|-----|-----|----------------|
| Day 1 | +148.69 | 348.69 |
| Day 2 | +129.93 | 478.61 |
| Day 3 | +0.00 | 478.61 |
| Day 4 | +0.00 | 478.61 |
| Day 5 | +0.00 | 478.61 |
| Day 6 | +0.00 | 478.61 |
| Day 7 | +0.00 | 478.61 |
| Day 8 | +0.00 | 478.61 |
| Day 9 | +0.00 | 478.61 |
| Day 10 | +0.00 | 478.61 |
| Day 11 | +0.00 | 478.61 |
| Day 12 | +0.00 | 478.61 |
| Day 13 | +0.00 | 478.61 |
| Day 14 | +0.00 | 478.61 |


## Comparison: v1 vs v2 (Apr 8 2026 Updates)

| Metric | v1 (Before) | v2 (After) | Change |
|--------|-------------|-------------|--------|
| Total Trades | 594 | 144 | -450 |
| Win Rate | 40.7% | 45.8% | +5.1pp |
| Net P&L | +1072 XRP | +278.61 XRP | -793.39 |
| Profit Factor | 4.24x | 4.98x | +0.74x |
| MICRO_SCALP WR | 0% | 33% | FIXED |
| CLOB_LAUNCH trades | 0 | 30 | + |
| PRE_BREAKOUT WR | 24% | 36% | +12pp |

---

## Backtest Methodology

- **Calibration:** Proven WIN_PROB matrix from backtest_upgraded.py (595 tokens)
- **Token universe:** 531 tokens (TVL ≥ 200 XRP)
- **Position sizing:** Fixed XRP amounts (8 normal, 12 elite, 5 micro)
- **Slippage:** 5% entry, 8% exit
- **Random seed:** 42 (reproducible)
- **Regime filter:** DANGER mode pauses entries when WR < 20%
