# DKTrenchBot v2 — MASTERPIECE CONFIG — 14-Day Backtest
**Generated:** 2026-04-08 15:28 UTC
**Method:** Calibrated Monte Carlo | 500 iterations × 14 days
**Starting Balance: 183.0 XRP**

---

## ⚙️ Masterpiece Config
| Parameter | Value |
|-----------|-------|
| Score Threshold | 30 |
| Elite Score (20% sizing) | 65 |
| Normal Score (12% sizing) | 50 |
| Small Score (6% sizing) | 40 |
| Max Positions | 10 |
| Min TVL | 200 XRP |
| Trail Stop | 30% from peak |
| Slippage Buffer | 10% |
| TP Ladder | 2x→50% \| 3x→20% \| 5x→remainder |

---

## 📊 Median Run Results

| Metric | Value |
|--------|-------|
| Starting Balance | 183.00 XRP |
| **Final Balance** | **481.05 XRP** |
| **Total PnL** | **+298.05 XRP** |
| **ROI** | **+162.9%** |
| **Total Trades** | **22** |
| Wins | 15 |
| Losses | 7 |
| **Win Rate** | **68.2%** |
| Avg Win | +24.63 XRP |
| Avg Loss | -10.19 XRP |
| Best Trade | +119.11 XRP (score=74, 5.0x) |
| Worst Trade | -17.40 XRP |

---

## 📉 Confidence Intervals (500 Runs)

| Scenario | Final Balance | PnL |
|----------|--------------|-----|
| P10 — Bad Run | 290.28 XRP | +107.28 XRP |
| P25 | 358.93 XRP | +175.93 XRP |
| **P50 — Median** | **481.05 XRP** | **+298.05 XRP** |
| P75 | 631.68 XRP | +448.68 XRP |
| P90 — Great Run | 807.08 XRP | +624.08 XRP |
| **Average** | **517.45 XRP** | **+334.45 XRP** |

> Avg **22 trades** across 500 runs | Avg win rate **64.6%**

---

## 📅 Daily PnL Breakdown (Median Run)

| Day | PnL (XRP) | Cumulative Balance |
|-----|-----------|--------------------|
| Day 1 | +14.71 | 197.71 XRP |
| Day 2 | +65.25 | 262.96 XRP |
| Day 3 | +0.01 | 262.97 XRP |
| Day 4 | +0.00 | 262.97 XRP |
| Day 5 | +153.91 | 416.88 XRP |
| Day 6 | -7.50 | 409.38 XRP |
| Day 7 | +19.04 | 428.41 XRP |
| Day 8 | -5.14 | 423.27 XRP |
| Day 9 | -7.61 | 415.66 XRP |
| Day 10 | +19.33 | 434.99 XRP |
| Day 11 | -17.39 | 417.60 XRP |
| Day 12 | -19.81 | 397.79 XRP |
| Day 13 | +83.25 | 481.04 XRP |
| Day 14 | +0.01 | 481.05 XRP |