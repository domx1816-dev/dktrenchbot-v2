# DKTrenchBot — 14-Day Backtest Report
**Generated:** 2026-04-07 19:40 UTC
**Backtest Window:** 2026-03-24 19:40 → 2026-04-07 19:40
**Tokens Analyzed:** 30
**Data Source:** XRPL on-chain AMM transactions via CLIO RPC

---

## ⚠️ Data Quality Notes

XRPL AMM price extraction from `AffectedNodes` is challenging because:
- `AMMSwap` transactions store pool state changes in `AMMState` ledger entries
- `AffectedNodes` structure varies between transaction types
- Some swaps go via DEX path (OfferCreate) vs direct AMM, making price extraction non-trivial
- Sparse data is common for lower-TVL tokens with few swaps/hour

- **Tokens with AMM data (≥5 bars):** 0
- **Sparse/missing data:** 30 tokens
- **Total trades simulated:** 0

---

## 📊 Overall Results

| Metric | Value |
|--------|-------|
| Total Trades | 0 |
| Win Rate | 0.0% |
| Total PnL | +0.00 XRP |
| Avg Win | +0.00 XRP |
| Avg Loss | +0.00 XRP |

## 🚪 Exit Breakdown

| Exit Reason | Count | % |
|-------------|-------|---|

---

## 📋 Per-Token Results

| Symbol | TVL (XRP) | Bars | Ticks | Trades | PnL XRP | WR% | Status |
|--------|-----------|------|-------|--------|---------|-----|--------|
| CRYPTO | 2,810,489 | 0 | 0 | — | — | — | ❌ sparse |
| FUZZY | 581,599 | 0 | 0 | — | — | — | ❌ sparse |
| MAG | 460,049 | 0 | 0 | — | — | — | ❌ sparse |
| XPM | 335,515 | 0 | 0 | — | — | — | ❌ sparse |
| PHNIX | 240,611 | 0 | 0 | — | — | — | ❌ sparse |
| ARMY | 203,900 | 0 | 0 | — | — | — | ❌ sparse |
| EVR | 106,874 | 0 | 0 | — | — | — | ❌ sparse |
| WETH | 95,568 | 0 | 0 | — | — | — | ❌ sparse |
| DROP | 90,965 | 0 | 0 | — | — | — | ❌ sparse |
| mXRP | 88,021 | 0 | 0 | — | — | — | ❌ sparse |
| BEAR | 86,961 | 0 | 0 | — | — | — | ❌ sparse |
| CNY | 85,720 | 0 | 0 | — | — | — | ❌ sparse |
| XRPS | 74,007 | 0 | 0 | — | — | — | ❌ sparse |
| CULT | 63,655 | 0 | 0 | — | — | — | ❌ sparse |
| ATM | 62,989 | 0 | 0 | — | — | — | ❌ sparse |
| SLT | 53,843 | 0 | 0 | — | — | — | ❌ sparse |
| ARMY | 51,212 | 0 | 0 | — | — | — | ❌ sparse |
| FLR | 45,486 | 0 | 0 | — | — | — | ❌ sparse |
| XAH | 45,153 | 0 | 0 | — | — | — | ❌ sparse |
| Opulence | 32,473 | 0 | 0 | — | — | — | ❌ sparse |
| CSC | 30,217 | 0 | 0 | — | — | — | ❌ sparse |
| BERT | 27,986 | 0 | 0 | — | — | — | ❌ sparse |
| XRPH | 27,625 | 0 | 0 | — | — | — | ❌ sparse |
| SIGMA | 25,702 | 0 | 0 | — | — | — | ❌ sparse |
| CORE | 25,378 | 0 | 0 | — | — | — | ❌ sparse |
| Horizon | 22,894 | 0 | 0 | — | — | — | ❌ sparse |
| bull | 22,324 | 0 | 0 | — | — | — | ❌ sparse |
| TOTO | 21,697 | 0 | 0 | — | — | — | ❌ sparse |
| BCHAMP | 21,397 | 0 | 0 | — | — | — | ❌ sparse |
| 666 | 20,318 | 0 | 0 | — | — | — | ❌ sparse |

---

## 📝 Trade Log

No trades were generated. See data quality notes above.

---

## 🔍 Methodology & Limitations

### Entry Rules Applied
- `pre_breakout`: price within 20% of 24-bar local high
- Score ≥ 57 (or ≥45 with micro-vel override)
- Momentum: +1% over 2 bars
- TVL ≥ 300 XRP

### Scoring Model
- TVL tiers: <500→8, <2k→15, <10k→25, <100k→35, 100k+→50 pts
- Momentum tiers: ≥1%→20, ≥2%→30, ≥5%→40, ≥10%→50 pts
- Cap: 100 pts

### Key Limitations
1. **Price extraction**: AMMSwap AffectedNodes parsing is best-effort. If AMMState changes didn't capture XRP+token deltas simultaneously, the tick is skipped → sparse bars → fewer simulated trades than reality.
2. **No slippage model**: Real AMM swaps have price impact. Large positions would move price more.
3. **Simplified scoring**: Real bot scoring includes DNA60, VWAP, liquidity health checks not reproduced here.
4. **Hourly bars**: Real bot runs at 60-second poll intervals — higher resolution would produce different entry/exit signals.
5. **Single token, no concurrent positions**: Real bot holds up to 3 concurrent positions (MAX_POSITIONS=3).
6. **No real cost data**: Doesn't account for AMM swap fees (0.5-1% typically on XRPL AMM).