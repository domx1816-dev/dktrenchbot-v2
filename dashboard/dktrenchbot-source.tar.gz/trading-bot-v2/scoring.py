"""
scoring.py — Composite token score (0-100).
Components:
  breakout_quality:   0-25 pts
  chart_state:        0-20 pts
  liquidity_depth:    0-15 pts
  issuer_safety:      0-10 pts
  route_quality:      0-10 pts
  smart_money:        0-10 pts
  extension_penalty: -20-0 pts
  regime_bonus:      -10-+5 pts

Thresholds: 85+=elite, 70-84=tradeable, 60-69=small_size, <60=skip
"""

from typing import Dict, Optional
from config import SCORE_ELITE, SCORE_TRADEABLE, SCORE_SMALL


def get_tg_signal_boost(symbol: str) -> int:
    """Check tg_signals.json for an active social signal boost for this token."""
    import json, time
    from pathlib import Path
    sig_file = Path(__file__).parent / "state" / "tg_signals.json"
    if not sig_file.exists():
        return 0
    try:
        signals = json.loads(sig_file.read_text())
        sig = signals.get(symbol.upper())
        if sig and sig.get("expires", 0) > time.time():
            return int(sig.get("strength", 0))
    except Exception:
        pass
    return 0


def compute_score(
    breakout_quality:  int   = 0,
    chart_state:       str   = "dead",
    chart_confidence:  float = 0.5,
    tvl_xrp:          float = 0.0,
    issuer_safe:       bool  = False,
    issuer_warnings:   int   = 0,
    route_slippage:    float = 0.05,
    route_exit_ok:     bool  = True,
    smart_money_boost: int   = 0,     # 0, 10, or 20
    extension_pct:     float = 0.0,   # total price move from entry
    tvl_change_pct:    float = 0.0,   # TVL % change vs last reading (momentum signal)
    regime:            str   = "neutral",
    regime_override:   bool  = False,
    symbol:            str   = "",    # for TG signal lookup
) -> Dict:
    """
    Compute composite score. Returns dict with total and breakdown.
    """
    breakdown = {}

    # 1. Breakout quality: 0-35 pts (primary signal — learned 2026-04-03)
    # Linear up to BQ=60, then bonus acceleration for high conviction
    if breakout_quality >= 80:
        bq_pts = 35
    elif breakout_quality >= 60:
        bq_pts = 25 + int((breakout_quality - 60) * 0.5)   # 25-35 pts
    else:
        bq_pts = int(breakout_quality * 0.42)               # 0-25 pts
    breakdown["breakout_quality"] = bq_pts

    # 2. Chart state quality: 0-20 pts
    from chart_intelligence import get_chart_state_score
    cs_pts = get_chart_state_score(chart_state)
    # Scale by confidence
    cs_pts = int(cs_pts * chart_confidence)
    breakdown["chart_state"] = cs_pts

    # 3. Liquidity depth: 0-30 pts
    # DATA: PHX/ROOS/SPY all launched at 2K-15K XRP — thin pools = big moves
    # Previous sweet spot of 20K-100K was WRONG — those pools are too mature/slow
    # New sweet spot: 3K-20K (early stage, still moveable by small capital)
    if 5_000 <= tvl_xrp < 20_000:
        liq_pts = 30   # ⭐ PHX/ROOS/SPY sweet spot — thin enough to move
    elif 3_000 <= tvl_xrp < 5_000:
        liq_pts = 25   # early stage — high volatility window
    elif 1_000 <= tvl_xrp < 3_000:
        liq_pts = 15   # ultra thin — higher slippage but fast moves
    elif 20_000 <= tvl_xrp < 60_000:
        liq_pts = 15   # mid-size — already discovered, slower
    elif tvl_xrp >= 60_000:
        liq_pts = 8    # large/mature — hard to move, unlikely 5x
    else:
        liq_pts = 0    # too thin (<1K XRP)

    # TVL momentum bonus: rapidly growing pool = strong entry signal (+0 to +10 pts)
    if tvl_change_pct >= 0.50:
        liq_pts = min(liq_pts + 10, 30)  # TVL up 50%+ — something is happening
    elif tvl_change_pct >= 0.25:
        liq_pts = min(liq_pts + 6, 30)
    elif tvl_change_pct >= 0.10:
        liq_pts = min(liq_pts + 3, 30)

    breakdown["liquidity_depth"] = liq_pts

    # 4. Issuer safety: 0-10 pts
    if issuer_safe:
        issuer_pts = 10
    elif issuer_warnings == 0:
        issuer_pts = 6
    else:
        issuer_pts = max(0, 6 - issuer_warnings * 2)
    breakdown["issuer_safety"] = issuer_pts

    # 5. Route quality: 0-10 pts
    if route_slippage <= 0.005:
        route_pts = 10
    elif route_slippage <= 0.01:
        route_pts = 8
    elif route_slippage <= 0.02:
        route_pts = 5
    elif route_slippage <= 0.03:
        route_pts = 2
    else:
        route_pts = 0
    if not route_exit_ok:
        route_pts = max(0, route_pts - 5)
    breakdown["route_quality"] = route_pts

    # 6. Smart money: 0-10 pts
    sm_pts = min(10, smart_money_boost)
    breakdown["smart_money"] = sm_pts

    # 6b. TG social signal boost: 0-30 pts (from tg_signal_listener.py)
    tg_boost = get_tg_signal_boost(symbol) if symbol else 0
    breakdown["tg_signal"] = tg_boost

    # 7. Extension penalty: -20 to 0
    if extension_pct >= 0.50:
        ext_penalty = -20
    elif extension_pct >= 0.35:
        ext_penalty = -15
    elif extension_pct >= 0.25:
        ext_penalty = -10
    elif extension_pct >= 0.15:
        ext_penalty = -5
    else:
        ext_penalty = 0
    breakdown["extension_penalty"] = ext_penalty

    # 8. Regime bonus: -10 to +5
    regime_bonus = {
        "hot":     5,
        "neutral": 0,
        "cold":   -5,
        "danger": -10,
    }.get(regime, 0)
    breakdown["regime_bonus"] = regime_bonus

    total = sum(breakdown.values())
    total = max(0, min(100, total))

    band = "skip"
    if total >= SCORE_ELITE:
        band = "elite"
    elif total >= SCORE_TRADEABLE:
        band = "tradeable"
    elif total >= SCORE_SMALL:
        band = "small_size"

    return {
        "total":     total,
        "band":      band,
        "breakdown": breakdown,
    }


def position_size(score: int, regime: str, base_xrp: float = 5.0,
                  elite_xrp: float = 7.5, small_xrp: float = 2.5,
                  bq: int = 50, wallet_xrp: float = 0.0) -> float:
    """
    Kelly-influenced position sizing.
    Uses score as proxy for win probability, BQ as edge signal.
    Axiom-inspired: fraction of deployable capital, not fixed size.
    """
    if regime == "danger":
        return 0.0

    regime_mult = {"hot": 1.0, "neutral": 1.0, "cold": 0.5}.get(regime, 1.0)

    # Score → win probability proxy (40=0.40, 65=0.65, 80=0.75 cap)
    win_prob = min(0.40 + (score - 40) * 0.006, 0.75) if score >= 40 else 0.40

    # BQ → estimated payout proxy (higher BQ = more edge = better odds)
    if bq >= 80:   payout_est = 2.2
    elif bq >= 65: payout_est = 1.9
    elif bq >= 50: payout_est = 1.6
    else:          payout_est = 1.4

    # Kelly fraction: f = (prob × payout - 1) / (payout - 1)
    kelly_full = (win_prob * payout_est - 1.0) / (payout_est - 1.0)
    kelly_frac = max(kelly_full * 0.25, 0)  # use 25% Kelly (conservative)

    # If wallet provided, use Kelly fraction of deployable capital
    if wallet_xrp > 10:
        kelly_size = kelly_frac * wallet_xrp
    else:
        # Fallback to fixed bands if no wallet info
        if score >= SCORE_ELITE:   kelly_size = elite_xrp
        elif score >= SCORE_TRADEABLE: kelly_size = base_xrp
        else:                      kelly_size = small_xrp

    # Hard caps per band (safety ceiling)
    if score >= SCORE_ELITE:   cap = elite_xrp
    elif score >= SCORE_TRADEABLE: cap = base_xrp
    else:                      cap = small_xrp

    if score < SCORE_SMALL:
        return 0.0

    # BQ conviction multiplier
    if bq >= 70:   bq_mult = 1.5
    elif bq >= 55: bq_mult = 1.25
    else:          bq_mult = 1.0

    # Final size: Kelly-derived, capped at band ceiling, floored at band minimum
    size = min(kelly_size * regime_mult * bq_mult, cap * bq_mult)
    size = max(size, small_xrp)  # never go below minimum

    return round(size, 2)


def size_multiplier(score: int, regime: str) -> float:
    """Legacy multiplier — kept for compatibility."""
    if regime == "danger":
        return 0.0
    base = {"hot": 1.2, "neutral": 1.0, "cold": 0.5}.get(regime, 1.0)
    if score >= SCORE_ELITE:
        return base * 1.5
    elif score >= SCORE_TRADEABLE:
        return base * 1.0
    elif score >= SCORE_SMALL:
        return base * 0.5
    else:
        return 0.0


if __name__ == "__main__":
    result = compute_score(
        breakout_quality=75,
        chart_state="pre_breakout",
        chart_confidence=0.8,
        tvl_xrp=15000,
        issuer_safe=True,
        route_slippage=0.015,
        route_exit_ok=True,
        smart_money_boost=10,
        extension_pct=0.08,
        regime="neutral",
    )
    print(f"Score: {result['total']} ({result['band']})")
    print(f"Breakdown: {result['breakdown']}")
