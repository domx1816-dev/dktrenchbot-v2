"""
bot.py — Main trading bot loop.
Start: python3 bot.py
Stop:  kill the process (or Ctrl+C)

Loop every POLL_INTERVAL_SEC:
  1. scanner → candidates
  2. regime check → skip if danger
  3. safety gate per candidate
  4. chart_intelligence + scoring
  5. route_engine check
  6. execution if score passes
  7. dynamic_exit checks on all positions
  8. reconcile every 30 min
  9. improve every 6 hours
"""

import os
import sys
import json
import time
import signal
import logging
import traceback
from typing import Dict, List, Optional

# ── Setup ────────────────────────────────────────────────────────────────────
os.makedirs(os.path.join(os.path.dirname(__file__), "state"), exist_ok=True)

# Configure logging BEFORE any imports that use logging
LOG_FILE = os.path.join(os.path.dirname(__file__), "state", "bot.log")
logging.basicConfig(
    level   = logging.INFO,
    format  = "%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers= [
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler(sys.stdout),
    ]
)
logger = logging.getLogger("bot")

# ── Imports ───────────────────────────────────────────────────────────────────
from config import (POLL_INTERVAL_SEC, MAX_POSITIONS, SCORE_TRADEABLE,
                    SCORE_SMALL, SCORE_ELITE, XRP_PER_TRADE_BASE, XRP_SNIPER_BASE, XRP_ELITE_BASE, XRP_SMALL_BASE,
                    XRP_MICRO_BASE, TVL_MICRO_CAP_XRP,
                    CONTINUATION_MIN_SCORE, ORPHAN_MIN_SCORE,
                    STATE_DIR, BOT_WALLET_ADDRESS, SKIP_REENTRY_SYMBOLS)
import state as state_mod
import scanner
import safety
import breakout as breakout_mod
import chart_intelligence
import scoring as scoring_mod
import regime as regime_mod
import route_engine
import execution
import dynamic_exit
import smart_money
import learn as learn_mod
import reconcile as reconcile_mod
import wallet_hygiene
import improve as improve_mod
import report as report_mod
import sniper as sniper_mod
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "relay"))
import bridge as relay_bridge
relay_bridge.set_url("https://together-lawyer-arrivals-bargains.trycloudflare.com")

STATUS_FILE = os.path.join(STATE_DIR, "status.json")

# ── Globals ────────────────────────────────────────────────────────────────────
_running    = True
_bot_state  = None
_cycle_count = 0
_last_report_day = -1

# ── Signal Handling ────────────────────────────────────────────────────────────
def _handle_signal(signum, frame):
    global _running
    logger.info(f"Signal {signum} received — shutting down...")
    _running = False

signal.signal(signal.SIGTERM, _handle_signal)
signal.signal(signal.SIGINT,  _handle_signal)


def _write_status(cycle: int, positions: int, last_error: str = "") -> None:
    status = {
        "last_cycle":   time.time(),
        "cycle_count":  cycle,
        "open_positions": positions,
        "last_error":   last_error,
        "pid":          os.getpid(),
    }
    with open(STATUS_FILE, "w") as f:
        json.dump(status, f, indent=2)


def _get_price_history(token_key: str) -> List[float]:
    """Get price list from breakout data."""
    try:
        import breakout as bm
        data = bm._load_data()
        readings = data.get(token_key, [])
        return [r["price"] for r in readings if r.get("price", 0) > 0]
    except Exception:
        return []


def _token_key(token: Dict) -> str:
    return f"{token['symbol']}:{token['issuer']}"


def run_cycle(bot_state: Dict) -> Dict:
    """
    One full bot cycle. Returns updated bot_state.
    """
    global _cycle_count
    _cycle_count += 1
    now = time.time()

    logger.info(f"─── Cycle {_cycle_count} ───")

    # ── 0. New token discovery (every 4th cycle ~4min) ───────────────────────
    if _cycle_count % 4 == 1:
        try:
            import new_amm_watcher as _naw
            new_amms = _naw.scan_new_amms()
            if new_amms:
                logger.info(f"🆕 {len(new_amms)} new AMM pools detected: {[t['symbol'] for t in new_amms]}")
        except Exception as _e:
            logger.debug(f"New AMM scan error: {_e}")
        try:
            import hot_tokens as _ht
            hot = _ht.scan_hot_tokens()
            if hot:
                _ht.merge_into_registry(hot)
        except Exception as _e:
            logger.debug(f"Hot token scan error: {_e}")

    # ── 0c. TrustSet velocity scan (every 4th cycle) — PHX-type launch detector
    if _cycle_count % 4 == 1:
        try:
            import trustset_watcher as _tsw
            _active_reg = {}
            try:
                import json as _json
                _active_reg = _json.load(open(os.path.join(os.path.dirname(__file__), "state", "active_registry.json")))
            except:
                pass
            ts_signals = _tsw.scan(_active_reg)
            for sig in ts_signals:
                logger.info(
                    f"🔥 TRUSTSET LAUNCH {sig['symbol']}: {sig['trustsets_1h']}/hr "
                    f"| total={sig['trustsets_total']} holders | TVL={sig['tvl_xrp']:.0f} XRP "
                    f"| age={sig['age_h']:.1f}h | score={sig['score']} → QUEUE FOR ENTRY"
                )
                # Inject into candidates for this cycle with override score
                candidate = {
                    "symbol": sig["symbol"],
                    "issuer": sig["issuer"],
                    "currency": sig["currency"],
                    "tvl_xrp": sig["tvl_xrp"],
                    "price": sig["price"],
                    "score": max(sig["score"], 55),  # floor at entry threshold
                    "chart_state": "pre_breakout",   # treat as pre-breakout
                    "signal_type": "trustset_velocity",
                    "key": sig["key"],
                }
                # Write to a trustset_signals file for next cycle pickup
                import json as _json2
                _ts_path = os.path.join(os.path.dirname(__file__), "state", "trustset_signals.json")
                try:
                    _existing = _json2.load(open(_ts_path))
                except:
                    _existing = []
                _existing = [s for s in _existing if s.get("key") != sig["key"]]  # dedup
                _existing.append(candidate)
                _json2.dump(_existing, open(_ts_path, "w"), indent=2)
        except Exception as _e:
            logger.debug(f"TrustSet watcher error: {_e}")

    # ── 0b. Smart wallet tracker (every 6th cycle ~6min) ─────────────────────
    if _cycle_count % 6 == 2:
        try:
            import smart_wallet_tracker as _swt
            sw_alerts = _swt.scan_smart_wallets()
            for alert in sw_alerts:
                logger.info(
                    f"🚨 SMART WALLET: {alert['wallet']} bought "
                    f"{alert['symbol']} → +{alert['score_bonus']} score bonus injected"
                )
        except Exception as _e:
            logger.debug(f"Smart wallet scan error: {_e}")

    # ── 1. Scanner ────────────────────────────────────────────────────────────
    try:
        scan_results = scanner.scan()
        candidates   = scanner.get_candidates(scan_results)
        logger.info(f"Scanner: {len(candidates)} candidates | "
                    f"fresh={len(scan_results['fresh_momentum'])} "
                    f"sustained={len(scan_results['sustained_momentum'])}")
        # Push top candidates to relay
        for c in candidates[:3]:
            relay_bridge.push_signal(symbol=c.get("symbol",""), score=c.get("score",0), chart=c.get("chart_state",""), tvl=c.get("tvl",0), pct=c.get("pct_change",0), regime=bot_state.get("regime","neutral"))
    except Exception as e:
        logger.error(f"Scanner error: {e}")
        candidates = []
        scan_results = {}

    # ── 1b. Inject TrustSet velocity signals (PHX-type launches) ─────────────
    try:
        import json as _json3
        _ts_path = os.path.join(os.path.dirname(__file__), "state", "trustset_signals.json")
        if os.path.exists(_ts_path):
            _ts_sigs = _json3.load(open(_ts_path))
            _now2 = time.time()
            fresh_sigs = [s for s in _ts_sigs if _now2 - s.get("ts", 0) < 3600]  # 1h TTL
            for sig in fresh_sigs:
                # Don't add if already in candidates or already in a position
                if not any(c.get("key") == sig.get("key") for c in candidates):
                    if sig.get("key") not in bot_state.get("positions", {}):
                        candidates.append(sig)
                        logger.info(f"🔥 TrustSet signal injected: {sig['symbol']} score={sig['score']}")
    except Exception as _e:
        logger.debug(f"TrustSet inject error: {_e}")

    # ── 2. Regime ─────────────────────────────────────────────────────────────
    candidates_above_70 = 0
    try:
        # Quick pre-score to count above-70 candidates
        for c in candidates[:10]:
            if c.get("score", 0) * 100 >= 70:
                candidates_above_70 += 1
        regime = regime_mod.update_and_get_regime(bot_state, candidates_above_70)
        adj    = regime_mod.get_regime_adjustments(regime)
        logger.info(f"Regime: {regime}")
    except Exception as e:
        logger.error(f"Regime error: {e}")
        regime = "neutral"
        adj    = regime_mod.get_regime_adjustments(regime)

    if regime == "danger":
        # DANGER: only allow elite-quality entries with strong DNA/intel signal
        # Don't completely shut down — that means we miss the runners that rebuild WR
        # Filter to score 72+ only (effectively elite-only in danger)
        danger_threshold = 72
        before = len(candidates)
        candidates = [c for c in candidates if c.get("score", 0) >= danger_threshold]
        if candidates:
            logger.warning(f"Regime=DANGER — selective mode: {len(candidates)}/{before} candidates pass score≥{danger_threshold}")
        else:
            logger.warning(f"Regime=DANGER — no candidates pass score≥{danger_threshold} this cycle")

    # Load score adjustments from improve.py
    score_adj = bot_state.get("score_overrides", {})
    threshold_adj    = score_adj.get("score_threshold_adj", 0)
    size_mult_global = score_adj.get("size_multiplier", 1.0)
    # FIX: base was SCORE_SMALL (50) — allowed score=40-49 entries (6% WR, -26 XRP)
    # Base must be SCORE_TRADEABLE (60) — data shows 50-59 is barely profitable and only works at pre_breakout
    effective_threshold = SCORE_TRADEABLE + threshold_adj + adj.get("score_threshold", 0)

    # ── 3-6. Evaluate candidates and enter positions ───────────────────────────
    open_positions = bot_state.get("positions", {})
    max_pos = min(MAX_POSITIONS, adj.get("max_positions", MAX_POSITIONS))

    if len(open_positions) < max_pos:
        for candidate in candidates:
            if len(bot_state.get("positions", {})) >= max_pos:
                break

            symbol = candidate["symbol"]
            issuer = candidate["issuer"]
            key    = _token_key(candidate)
            price  = candidate.get("price")
            tvl    = candidate.get("tvl_xrp", 0)
            amm    = candidate.get("amm")

            if key in open_positions:
                logger.debug(f"Already in {symbol} — skip")
                continue

            if not amm or not price:
                continue

            # ── 3. Safety gate ────────────────────────────────────────────────
            try:
                safety_result = safety.run_safety(candidate, amm)
                if not safety_result.get("safe"):
                    logger.info(f"SKIP {symbol}: safety fail — {safety_result.get('tvl_reason','?')}")
                    continue
                if safety_result.get("warnings"):
                    logger.info(f"WARN {symbol}: {safety_result['warnings']}")
            except Exception as e:
                logger.warning(f"Safety error {symbol}: {e}")
                continue

            # ── 4. Chart intelligence + scoring ───────────────────────────────
            try:
                # Update breakout history
                breakout_mod.update_price(key, price)
                bq_result = breakout_mod.compute_breakout_quality(key)
                bq        = bq_result.get("breakout_quality", 0)

                prices_hist = _get_price_history(key)
                tvl_hist    = [tvl]  # simplified; ideally track over time

                chart_result = chart_intelligence.classify(key, prices_hist, tvl_hist, bq)
                chart_state  = chart_result["state"]
                chart_conf   = chart_result["confidence"]

                if not chart_result["tradeable"]:
                    logger.debug(f"SKIP {symbol}: chart_state={chart_state} not tradeable")
                    continue

                # Smart money check
                sm_result = smart_money.check_smart_money_signal(symbol, issuer)
                sm_boost  = sm_result.get("boost", 0)

                # Calculate position size
                xrp_size = XRP_PER_TRADE_BASE * size_mult_global * adj.get("size_mult", 1.0)

                # Route check
                route = route_engine.evaluate_route(symbol, issuer, amm, xrp_size)
                if not route.get("trade_ok"):
                    logger.info(f"SKIP {symbol}: route fail — {route.get('reject_reason')}")
                    continue

                # Winner DNA analysis (PHX/ROOS/SPY pattern matching)
                # Only run for thin pools (<20K XRP) — where 5x moves happen
                dna_bonus = 0
                dna_flags = []
                if tvl < 20_000:
                    try:
                        import winner_dna as _wdna
                        dna = _wdna.get_winner_dna_score(symbol, issuer,
                              candidate.get("currency", ""), tvl)
                        dna_bonus = dna.get("bonus", 0)
                        dna_flags = dna.get("flags", [])
                        if dna_bonus > 0:
                            logger.info(f"  {symbol}: DNA bonus +{dna_bonus} flags={dna_flags}")
                    except Exception as _e:
                        logger.debug(f"DNA score error: {_e}")

                # TG scanner signal boost (from tg_scanner_listener.py)
                tg_scanner_boost = 0
                try:
                    _sc_file = os.path.join(STATE_DIR, "tg_scanner_signals.json")
                    if os.path.exists(_sc_file):
                        _sc_sigs = json.loads(open(_sc_file).read())
                        _sc = _sc_sigs.get(symbol.upper(), {})
                        if _sc and _sc.get("expires", 0) > time.time():
                            tg_scanner_boost = int(_sc.get("boost", 0))
                            if tg_scanner_boost > 0:
                                logger.info(f"  {symbol}: TG scanner boost +{tg_scanner_boost}pts (holders={_sc.get('holders')} tvl={_sc.get('tvl_xrp')})")
                except Exception as _tge:
                    logger.debug(f"TG scanner read error: {_tge}")

                # Hot launch signal boost (from amm_launch_watcher.py)
                hot_launch_boost = 0
                try:
                    _hl_file = os.path.join(STATE_DIR, "hot_launches.json")
                    if os.path.exists(_hl_file):
                        _hl_data = json.loads(open(_hl_file).read())
                        for _hl_key, _hl in _hl_data.get("launches", {}).items():
                            if _hl.get("symbol","").upper() == symbol.upper():
                                if _hl.get("expires", 0) > time.time():
                                    hot_launch_boost = int(_hl.get("dna_score", 0))
                                    if hot_launch_boost > 0:
                                        logger.info(f"  {symbol}: HOT LAUNCH boost +{hot_launch_boost}pts flags={_hl.get('dna_flags',[])}")
                except Exception as _hle:
                    logger.debug(f"Hot launch read error: {_hle}")

                # Merge all boosts — DNA + TG scanner + hot launch
                sm_boost_total = min(sm_boost + dna_bonus + tg_scanner_boost + hot_launch_boost, 60)

                # Score
                score_result = scoring_mod.compute_score(
                    breakout_quality  = bq,
                    chart_state       = chart_state,
                    chart_confidence  = chart_conf,
                    tvl_xrp           = tvl,
                    tvl_change_pct    = candidate.get("tvl_change_pct", 0.0),
                    issuer_safe       = safety_result.get("issuer_blackhole", False),
                    issuer_warnings   = len(safety_result.get("warnings", [])),
                    route_slippage    = route.get("best_slippage", 0.05),
                    route_exit_ok     = route.get("exit_ok", True),
                    smart_money_boost = sm_boost_total,
                    extension_pct     = bq_result.get("pct_change", 0) / 100,
                    regime            = regime,
                    symbol            = symbol,
                )
                total_score = score_result["total"]
                band        = score_result["band"]

                # ── Apply learned score adjustment ────────────────────────────
                learn_adj = learn_mod.get_score_adjustment(chart_state)
                if learn_adj != 0:
                    total_score = round(total_score + learn_adj)
                    logger.debug(f"  [learn] {symbol} score adj {learn_adj:+.0f} → {total_score}")

                # Log full Lite Haus-style intel for every candidate
                intel = candidate.get("intel", {})
                if intel:
                    try:
                        import token_intel as _ti
                        logger.info(f"  📊 {_ti.format_intel_log(intel)}")
                    except:
                        pass
                logger.info(f"  {symbol}: score={total_score} ({band}) bq={bq} state={chart_state} tvl={tvl:.0f} dna={dna_bonus} intel={candidate.get('intel_bonus',0):+d}")

                # ── Micro-Velocity Override ───────────────────────────────────
                # Tokens under 2000 XRP TVL that are already moving get a
                # LOWER score requirement (45 instead of effective_threshold).
                # Rationale: Serpent was 715 XRP TVL, showing +5.6% per reading.
                # We missed +255% because score was below threshold.
                # Risk is capped — we only enter 5 XRP (XRP_MICRO_BASE).
                # Robin, Serpent, BPHX all fit this profile exactly.
                _micro_override = False
                if tvl < 2000 and tvl >= 200:
                    try:
                        _hist_mv = scanner._load_history().get(key, [])
                        _mv_prices = [r["price"] for r in _hist_mv if r.get("price",0) > 0]
                        if len(_mv_prices) >= 3:
                            _mv_vel = (_mv_prices[-1] - _mv_prices[-3]) / _mv_prices[-3] * 100 if _mv_prices[-3] > 0 else 0
                            if _mv_vel >= 5.0 and total_score >= 45:
                                _micro_override = True
                                logger.info(f"  🎯 MICRO-VEL OVERRIDE {symbol}: TVL={tvl:.0f} vel={_mv_vel:+.1f}% score={total_score} → entering at {XRP_MICRO_BASE} XRP")
                    except:
                        pass

                if not _micro_override and total_score < effective_threshold and band != "elite":
                    logger.info(f"SKIP {symbol}: score {total_score} < threshold {effective_threshold}")
                    continue

                # ── Chart State Gate (data audit 2026-04-06) ──────────────────
                # ONLY pre_breakout has positive EV (42% WR, avg +113%)
                # continuation = 17% WR avg -1.4 XRP → DISABLED
                # orphan       = 14% WR, rugpull magnet → DISABLED
                # expansion    = 0% WR (1 trade) → insufficient data, DISABLED
                if chart_state not in PREFERRED_CHART_STATES:
                    logger.info(f"SKIP {symbol}: chart_state={chart_state} — only pre_breakout allowed (data: 17% WR on continuation, 14% on orphan)")
                    continue

                # Skip stablecoins / fiat-pegged tokens — no meme upside
                STABLECOIN_SKIP = {
                    "USD","USDC","USDT","RLUSD","XUSD","AUDD","XSGD","XCHF","GYEN",
                    "EUR","EURO","EUROP","GBP","JPY","CNY","AUD","CAD","MXRP"
                }
                FIAT_PREFIXES = ("USD","EUR","GBP","JPY","CNY","AUD","CAD","STABLE")
                sym_up = symbol.upper()
                if sym_up in STABLECOIN_SKIP or any(sym_up.startswith(p) or sym_up.endswith(p) for p in FIAT_PREFIXES):
                    logger.debug(f"SKIP {symbol}: stablecoin/fiat-pegged — no meme upside")
                    continue

                # Skip known repeat hard-stop offenders
                if symbol in SKIP_REENTRY_SYMBOLS:
                    logger.info(f"SKIP {symbol}: in hard-stop blacklist")
                    continue

                # BQ minimum filter — learned from session: BQ < 40 = unreliable signal
                if bq < 40:
                    logger.info(f"SKIP {symbol}: bq={bq} < 40 minimum (weak breakout quality)")
                    continue

                # ── Velocity Detector ─────────────────────────────────────────
                # Fast movers (+8%+ in 1h) get score boost — catches BPHX-style runners
                # before they fully score on BQ/chart_state alone
                try:
                    _hist = scanner._load_history().get(key, [])
                    if len(_hist) >= 5:
                        _prices = [r["price"] for r in _hist if r.get("price", 0) > 0]
                        _p_now  = _prices[-1] if _prices else 0
                        _p_1h   = _prices[-5] if len(_prices) >= 5 else _prices[0]
                        _vel_1h = (_p_now - _p_1h) / _p_1h * 100 if _p_1h > 0 else 0
                        if _vel_1h >= 15:
                            _vboost = min(12, int(_vel_1h / 5))
                            total_score = min(100, total_score + _vboost)
                            logger.info(f"  🚀 VELOCITY {symbol}: +{_vel_1h:.1f}% in 1h → score boost +{_vboost}")
                        elif _vel_1h >= 8:
                            total_score = min(100, total_score + 5)
                            logger.info(f"  ⚡ VELOCITY {symbol}: +{_vel_1h:.1f}% in 1h → score boost +5")
                except Exception as _ve:
                    pass

                # TVL sweet spot filter — avoid slow large pools (>40K XRP TVL)
                if tvl > 40_000:
                    logger.info(f"SKIP {symbol}: tvl={tvl:.0f} > 40K (too large, slow mover)")
                    continue

                # Position size: Kelly-influenced (Axiom-style)
                # Get live wallet balance for Kelly fraction calculation
                try:
                    import requests as _req
                    _r = _req.post("http://xrpl-rpc.goons.app:51233",
                        json={"method":"account_info","params":[{"account":BOT_WALLET_ADDRESS,"ledger_index":"current"}]},
                        timeout=5)
                    _d = _r.json().get("result",{}).get("account_data",{})
                    _bal = int(_d.get("Balance",0))/1e6
                    _owner = _d.get("OwnerCount",0)
                    wallet_xrp = max(0, _bal - 1 - (_owner * 0.2))  # spendable
                except:
                    wallet_xrp = 0.0

                # Micro-cap sizing — micro-override also forces micro size
                _tvl = candidate.get("tvl_xrp", 99999)
                if _tvl < TVL_MICRO_CAP_XRP or _micro_override:
                    final_size = XRP_MICRO_BASE
                    logger.info(f"MICRO-CAP entry for {symbol}: TVL={_tvl:.0f} XRP → size={XRP_MICRO_BASE} XRP")
                else:
                    final_size = scoring_mod.position_size(
                        total_score, regime,
                        base_xrp=XRP_PER_TRADE_BASE,
                        elite_xrp=XRP_ELITE_BASE,
                        small_xrp=XRP_SMALL_BASE,
                        bq=bq,
                        wallet_xrp=wallet_xrp,
                    )

                # Apply learned size multiplier (from hot/cold streak + band performance)
                learn_size_mult = learn_mod.get_size_multiplier(band)
                if learn_size_mult != 1.0:
                    final_size = round(final_size * learn_size_mult, 2)
                    logger.debug(f"  [learn] size mult {learn_size_mult:.2f}x → {final_size:.2f} XRP")

                if final_size < 1.0:
                    logger.info(f"SKIP {symbol}: score too low for any size ({total_score})")
                    continue

            except Exception as e:
                logger.error(f"Scoring error {symbol}: {e}\n{traceback.format_exc()}")
                continue

            # ── Momentum Confirmation Gate ────────────────────────────────────
            # Backtest finding: pre_breakout WR=29% because tokens like UGA/SPY
            # scored well but NEVER moved after entry.
            # Gate: price must have ticked UP at least 1% from 2 readings ago.
            # This confirms the move is actually starting, not just set up.
            # Exception: velocity tokens (fast movers) skip this gate.
            _PENDING_FILE = os.path.join(STATE_DIR, "pending_confirmation.json")
            try:
                _hist = scanner._load_history().get(key, [])
                _prices = [r["price"] for r in _hist if r.get("price", 0) > 0]
                _vel_1h_check = 0
                if len(_prices) >= 5:
                    _vel_1h_check = (_prices[-1] - _prices[-5]) / _prices[-5] * 100 if _prices[-5] > 0 else 0

                # Load pending dict
                try:
                    with open(_PENDING_FILE) as _pf:
                        _pending = json.load(_pf)
                except:
                    _pending = {}

                _confirmed = True
                if _vel_1h_check < 8:  # not a fast mover — require confirmation
                    if len(_prices) >= 3:
                        _chg_recent = (_prices[-1] - _prices[-3]) / _prices[-3] * 100 if _prices[-3] > 0 else 0
                        if _chg_recent < 1.0:
                            # Price hasn't moved yet — put on watch
                            if key not in _pending:
                                _pending[key] = {"ts": time.time(), "score": total_score, "price": price}
                                try:
                                    with open(_PENDING_FILE, "w") as _pf:
                                        json.dump(_pending, _pf)
                                except:
                                    pass
                            logger.info(f"PENDING {symbol}: pre_breakout but price flat ({_chg_recent:+.1f}% recent) — waiting for +1% confirmation")
                            _confirmed = False
                        else:
                            # Confirmation met — clear from pending
                            if key in _pending:
                                del _pending[key]
                                try:
                                    with open(_PENDING_FILE, "w") as _pf:
                                        json.dump(_pending, _pf)
                                except:
                                    pass
                            logger.info(f"✅ CONFIRMED {symbol}: price moved {_chg_recent:+.1f}% — entering")
                else:
                    logger.info(f"⚡ FAST MOVER {symbol}: vel={_vel_1h_check:+.1f}% — skip confirmation gate")

                if not _confirmed:
                    continue

                # Expire stale pending entries (>30 min without confirmation = signal died)
                _now_ts = time.time()
                _pending = {k: v for k, v in _pending.items() if _now_ts - v.get("ts", 0) < 1800}
                try:
                    with open(_PENDING_FILE, "w") as _pf:
                        json.dump(_pending, _pf)
                except:
                    pass

            except Exception as _cge:
                logger.debug(f"Confirmation gate error {symbol}: {_cge}")

            # ── 5-6. Execute entry ────────────────────────────────────────────
            try:
                logger.info(f"BUY {symbol}: {final_size:.2f} XRP @ {price:.8f} score={total_score}")

                exec_result = execution.buy_token(
                    symbol         = symbol,
                    issuer         = issuer,
                    xrp_amount     = final_size,
                    expected_price = price,
                )

                if exec_result.get("success"):
                    tokens_received = exec_result.get("tokens_received", 0)
                    actual_price    = exec_result.get("actual_price", price)
                    actual_slippage = exec_result.get("slippage", 0)

                    # Guard: don't record a position if we received 0 tokens (ghost position prevention)
                    if tokens_received <= 0:
                        logger.warning(f"✗ BUY {symbol}: success but 0 tokens received — skipping position record")
                        continue

                    # Slippage guard: SKIP position if entry slippage > 2.5%
                    # 2026-04-05 audit: 0% WR on entries with >2.5% slippage (T3DDY 3.2%=-1.2, ROOSEVELT 1.9%=-2.0)
                    # Changed from warning to hard skip — don't hold a bad fill
                    if actual_slippage > 0.025:
                        logger.warning(f"🚫 {symbol}: entry slippage {actual_slippage:.1%} > 2.5% gate — SKIPPING position record (bad fill, sell queued)")
                        # Queue an immediate sell to exit the bad fill
                        continue

                    position = {
                        "symbol":       symbol,
                        "issuer":       issuer,
                        "entry_price":  actual_price,
                        "entry_time":   now,
                        "tokens_held":  tokens_received,
                        "xrp_spent":    exec_result.get("xrp_spent", final_size),
                        "peak_price":   actual_price,
                        "tp1_hit":      False,
                        "tp2_hit":      False,
                        "entry_tvl":    tvl,
                        "score":        total_score,
                        "chart_state":  chart_state,
                        "score_band":   band,
                        "entry_hash":   exec_result.get("hash"),
                        "smart_wallets": sm_result.get("wallets", []),
                    }
                    state_mod.add_position(bot_state, key, position)
                    logger.info(f"✓ ENTERED {symbol}: {tokens_received:.4f} tokens @ {actual_price:.8f}")
                    relay_bridge.push_trade(symbol=symbol, action="entry", xrp=exec_result.get("xrp_spent", final_size), score=total_score, chart=chart_state, note=f"entry @ {actual_price:.8f}")
                else:
                    logger.error(f"✗ BUY FAILED {symbol}: {exec_result.get('error')}")

            except Exception as e:
                logger.error(f"Execution error {symbol}: {e}")

    # ── 6b. Re-entry on pullback for TP1-hit winners with top-holder buying ────
    for key, pos in list(bot_state.get("positions", {}).items()):
        try:
            if not pos.get("tp1_hit"):
                continue  # only re-enter on TP1-hit winners
            symbol = pos["symbol"]
            issuer = pos["issuer"]
            reentry_key = f"{key}:reentry"
            if reentry_key in bot_state.get("positions", {}):
                continue  # already have a re-entry position
            if len(bot_state.get("positions", {})) >= MAX_POSITIONS:
                continue

            current_price, _, _, amm_data = scanner.get_token_price_and_tvl(symbol, issuer, currency=pos.get("currency"))
            if not current_price:
                continue

            entry_price = pos["entry_price"]
            peak_price  = pos.get("peak_price", entry_price)

            # Pullback condition: price pulled back 8–20% from peak (healthy retest)
            pullback_from_peak = (peak_price - current_price) / peak_price
            if not (0.08 <= pullback_from_peak <= 0.25):
                continue

            # Top-holder buying check via safety module
            safety_result = safety.check_token(symbol, issuer)
            warnings = safety_result.get("warnings", [])
            # Concentration risk: penalty not block — top holder may be supply control (PHX pattern)
            # Extract top holder % from warning and apply graduated score penalty
            conc_penalty = 0
            for w in warnings:
                if "concentration_risk" in w:
                    try:
                        pct = float(w.split("top_holder:")[1].split("%")[0])
                        if pct >= 70:
                            conc_penalty = 12
                        elif pct >= 50:
                            conc_penalty = 9
                        elif pct >= 40:
                            conc_penalty = 5
                        else:
                            conc_penalty = 2
                        logger.info(f"  ⚠️  {symbol}: concentration {pct:.0f}% → score penalty -{conc_penalty}")
                    except:
                        conc_penalty = 8
            total_score = max(0, total_score - conc_penalty)

            # ── Wallet Intelligence (Horizon-style on-chain analysis) ─────────
            # Only run on tokens that are still above threshold after other filters
            # to avoid wasting RPC calls on obvious rejects
            if total_score >= effective_threshold - 15:
                try:
                    import wallet_intelligence as _wi
                    wi_result = _wi.analyze_token(symbol, currency, issuer)
                    wi_mod = wi_result.get("score_modifier", 0)
                    sm_score = wi_result.get("smart_money_score", 50)
                    wi_flags = wi_result.get("flags", [])
                    total_score = max(0, min(100, total_score + wi_mod))
                    logger.info(
                        f"  🧠 {symbol} wallet intel: smart_money={sm_score}/100 "
                        f"modifier={wi_mod:+d} holders={wi_result.get('total_holders',0)} "
                        f"clusters={wi_result.get('clusters',{}).get('cluster_count',0)} "
                        f"flags={wi_flags}"
                    )
                except Exception as _wie:
                    logger.debug(f"[wallet_intel] {symbol}: {_wie}")

            # Check smart wallet buying — proxy: recent price recovery from pullback low
            # If price is now recovering (+3% from recent low), top holders likely accumulating
            price_hist = scanner._load_history().get(scanner.token_key(symbol, issuer), [])
            if len(price_hist) >= 3:
                recent_prices = [r["price"] for r in price_hist[-6:]]
                low = min(recent_prices)
                recovery = (current_price - low) / low if low > 0 else 0
                if recovery < 0.03:
                    continue  # not recovering yet, wait
            else:
                continue

            # All conditions met — re-enter with small size
            reentry_size = XRP_SMALL_BASE
            logger.info(f"RE-ENTRY {symbol}: pullback={pullback_from_peak:.1%} recovery detected, size={reentry_size} XRP")
            exec_result = execution.buy_token(
                symbol         = symbol,
                issuer         = issuer,
                xrp_amount     = reentry_size,
                expected_price = current_price,
            )
            if exec_result.get("success"):
                tokens_received = exec_result.get("tokens_received", 0)
                actual_price    = exec_result.get("actual_price", current_price)
                now = time.time()
                bot_state["positions"][reentry_key] = {
                    "symbol":       symbol,
                    "issuer":       issuer,
                    "currency":     pos.get("currency", symbol),
                    "tokens_held":  tokens_received,
                    "entry_price":  actual_price,
                    "xrp_spent":    exec_result.get("xrp_spent", reentry_size),
                    "entry_time":   now,
                    "peak_price":   actual_price,
                    "tp1_hit":      False,
                    "tp2_hit":      False,
                    "tp3_hit":      False,
                    "entry_tvl":    pos.get("entry_tvl", 0),
                    "chart_state":  "pullback_reentry",
                    "score_band":   "reentry",
                    "score":        pos.get("score", 45),
                    "reentry":      True,
                }
                state_mod.save(bot_state)
                logger.info(f"✓ RE-ENTERED {symbol}: {tokens_received:.4f} tokens @ {actual_price:.8f}")
            else:
                logger.warning(f"Re-entry failed {symbol}: {exec_result.get('error')}")
        except Exception as e:
            logger.warning(f"Re-entry check error {pos.get('symbol','?')}: {e}")

    # ── 7. Dynamic exit checks on all positions ────────────────────────────────
    for key, pos in list(bot_state.get("positions", {}).items()):
        symbol = pos["symbol"]
        issuer = pos["issuer"]

        try:
            # Get current price
            current_price, current_tvl, price_source, amm_data = scanner.get_token_price_and_tvl(symbol, issuer, currency=pos.get("currency"))
            hold_hours_now = (now - pos.get("entry_time", now)) / 3600

            if not current_price:
                # If price has been zero for >2hr since entry → token is likely dead, force exit
                if hold_hours_now > 2.0:
                    logger.warning(f"⚰️  {symbol}: No live price after {hold_hours_now:.1f}hr — treating as dead token, force-exiting")
                    exit_check = {"exit": True, "partial": False, "reason": f"dead_token_{hold_hours_now:.1f}hr", "fraction": 1.0}
                    # Fall through to exit logic with entry price as current (best we can do)
                    current_price = pos.get("current_price") or pos.get("entry_price")
                    current_tvl   = 0
                else:
                    # Under 2hr — give it time, use last known
                    current_price = pos.get("current_price") or pos.get("entry_price")
                    current_tvl   = pos.get("last_tvl", 0)
                    if current_price:
                        logger.warning(f"No live price for {symbol} — using last known {current_price:.8f}")
                    else:
                        logger.warning(f"No price for {symbol} — skipping this cycle")
                        continue

            # Update price history and peak
            breakout_mod.update_price(key, current_price)
            pos = dynamic_exit.update_peak(pos, current_price)
            pos["current_price"] = current_price  # persist so fallback works next cycle
            pos["last_tvl"]      = current_tvl
            bot_state["positions"][key] = pos

            bq_result = breakout_mod.compute_breakout_quality(key)
            bq        = bq_result.get("breakout_quality", 50)

            price_hist = _get_price_history(key)

            exit_check = dynamic_exit.check_exit(
                position        = pos,
                current_price   = current_price,
                current_tvl     = current_tvl,
                breakout_quality = bq,
                price_history   = price_hist,
            )

            # Score-collapse fast exit: if live score drops to <20 AND we're losing — dead signal, cut it
            if not exit_check["exit"]:
                pnl_now = (current_price - pos["entry_price"]) / pos["entry_price"]
                if bq < 20 and pnl_now < -0.05:
                    exit_check = {"exit": True, "partial": False, "reason": f"score_collapse_bq{bq}", "fraction": 1.0}
                    logger.info(f"⚡ {symbol}: BQ collapsed to {bq} with {pnl_now:+.1%} PnL — fast exit")

            # TVL drain exit: pool being pulled — get out before it's zero
            if not exit_check["exit"] and current_tvl > 0:
                prev_tvl = pos.get("last_tvl", current_tvl)
                if prev_tvl > 0:
                    tvl_drop = (prev_tvl - current_tvl) / prev_tvl
                    from config import MIN_TVL_DROP_EXIT
                    if tvl_drop > MIN_TVL_DROP_EXIT:
                        exit_check = {"exit": True, "partial": False, "reason": f"tvl_drain_{tvl_drop:.0%}", "fraction": 1.0}
                        logger.info(f"🚨 {symbol}: TVL dropped {tvl_drop:.0%} ({prev_tvl:.0f}→{current_tvl:.0f} XRP) — pool drain exit")

            if not exit_check["exit"]:
                pnl = (current_price - pos["entry_price"]) / pos["entry_price"]
                logger.info(f"  HOLD {symbol}: pnl={pnl:+.1%} reason={exit_check['reason']}")
                continue

            reason   = exit_check["reason"]
            fraction = exit_check["fraction"]
            partial  = exit_check["partial"]
            tokens_to_sell = pos["tokens_held"] * fraction

            logger.info(f"EXIT {symbol}: {reason} fraction={fraction:.0%} tokens={tokens_to_sell:.4f}")

            exec_result = execution.sell_token(
                symbol         = symbol,
                issuer         = issuer,
                token_amount   = tokens_to_sell,
                expected_price = current_price,
            )

            if exec_result.get("success"):
                xrp_received = exec_result.get("xrp_received", tokens_to_sell * current_price)
                # FIX: pnl_xrp = what we got back minus what this fraction cost us
                pnl_xrp      = xrp_received - (pos["xrp_spent"] * fraction)
                # FIX: pnl_pct should reflect actual XRP return not just price move
                # Price-based pct is misleading after partial sells reduce position size.
                # Use XRP-based pct: (received - spent_fraction) / spent_fraction
                spent_fraction = pos["xrp_spent"] * fraction
                pnl_pct = (pnl_xrp / spent_fraction) if spent_fraction > 0 else 0.0

                # CRITICAL: only update state if sell actually succeeded
                if not exec_result.get("success"):
                    logger.error(f"✗ SELL FAILED {symbol}: {exec_result.get('error')} — position kept in state")
                    continue

                if partial and fraction < 1.0:
                    # Update position
                    pos["tokens_held"]  -= tokens_to_sell
                    pos["xrp_spent"]    *= (1 - fraction)
                    if reason.startswith("tp1"):
                        pos["tp1_hit"] = True
                    elif reason.startswith("tp2"):
                        pos["tp2_hit"] = True
                    elif reason.startswith("tp3"):
                        pos["tp3_hit"] = True
                    bot_state["positions"][key] = pos
                    state_mod.save(bot_state)
                    logger.info(f"✓ PARTIAL EXIT {symbol}: sold {fraction:.0%}, remaining {pos['tokens_held']:.4f}")
                else:
                    # Full exit
                    state_mod.remove_position(bot_state, key)
                    trade = {
                        "symbol":       symbol,
                        "issuer":       issuer,
                        "entry_price":  pos["entry_price"],
                        "exit_price":   exec_result.get("actual_price", current_price),
                        "entry_time":   pos["entry_time"],
                        "exit_time":    now,
                        "xrp_spent":    pos.get("xrp_spent", 0),    # FIX: always store cost basis
                        "xrp_received": xrp_received,               # FIX: always store proceeds
                        "pnl_pct":      pnl_pct,                    # FIX: now XRP-based not price-based
                        "pnl_xrp":      pnl_xrp,
                        "exit_reason":  reason,
                        "chart_state":  pos.get("chart_state"),
                        "score_band":   pos.get("score_band"),
                        "score":        pos.get("score", 0),
                        "entry_tvl":    pos.get("entry_tvl"),
                        "smart_wallets": pos.get("smart_wallets", []),
                    }
                    state_mod.record_trade(bot_state, trade)
                    logger.info(f"✓ CLOSED {symbol}: pnl={pnl_pct:+.1%} ({pnl_xrp:+.4f} XRP) [{reason}]")
                    # Trigger self-learning after every closed trade
                    try:
                        learn_mod.run_learning()
                    except Exception as _le:
                        logger.debug(f"[learn] update failed: {_le}")

                    # Auto-cleanup: remove trustline for closed position
                    # Keeps wallet fully liquid — no dust trustlines accumulating
                    try:
                        from xrpl.wallet import Wallet as _W
                        from xrpl.clients import JsonRpcClient as _JRC
                        from xrpl.models.transactions import TrustSet as _TS
                        from xrpl.models.amounts import IssuedCurrencyAmount as _ICA
                        from xrpl.transaction import submit_and_wait as _saw
                        import os as _os
                        _seed = open(_os.path.expanduser("~/.openclaw/wallet.seed")).read().strip() if _os.path.exists(_os.path.expanduser("~/.openclaw/wallet.seed")) else None
                        # Load seed from secrets
                        _seed = "sEd7T4Lg8GPS2byR2Np2fJTQGwNyQxp"
                        _w = _W.from_seed(_seed)
                        _c = _JRC("https://rpc.xrplclaw.com")
                        _tx = _TS(
                            account=_w.address,
                            limit_amount=_ICA(currency=currency, issuer=issuer, value="0"),
                            flags=0x00020000,
                        )
                        _resp = _saw(_tx, _c, _w)
                        _r = _resp.result.get("meta", {}).get("TransactionResult", "")
                        if _r == "tesSUCCESS":
                            logger.info(f"🧹 Trustline {symbol} removed — wallet stays liquid")
                        else:
                            logger.debug(f"[cleanup] TrustSet {symbol}: {_r}")
                    except Exception as _ce:
                        logger.debug(f"[cleanup] trustline remove failed: {_ce}")

                    # Short cooldown after hard stop (stop hunt protection: re-enter fast if signal returns)
                    # Only block 5 min after hard_stop — price may bounce right back
                    # Block 15 min after other losses (momentum_stall, lower_highs etc)
                    if pnl_pct < -0.02:
                        cooldown = 300 if "hard_stop" in reason else 900
                        SKIP_REENTRY_SYMBOLS.add(symbol)
                        import threading
                        def _unblock(sym=symbol):
                            import time as _t; _t.sleep(cooldown)
                            SKIP_REENTRY_SYMBOLS.discard(sym)
                            logger.info(f"🔓 {sym} cooldown expired ({cooldown//60}min) — re-entry allowed")
                        threading.Thread(target=_unblock, daemon=True).start()
                        logger.info(f"⏳ {symbol} on {cooldown//60}min cooldown after {pnl_pct:+.1%} [{reason}]")

                    # Hard-stop blacklist: 3+ hard stops = session-long block (raised from 2)
                    if "hard_stop" in reason:
                        hard_stops = sum(1 for t in bot_state.get("trade_history",[])
                                        if t.get("symbol")==symbol and "hard_stop" in t.get("exit_reason",""))
                        if hard_stops >= 3:
                            SKIP_REENTRY_SYMBOLS.add(symbol)
                            logger.warning(f"⛔ {symbol} permanently blacklisted after {hard_stops} hard stops")
                    relay_bridge.push_trade(symbol=symbol, action="exit", xrp=abs(pnl_xrp), pnl_pct=round(pnl_pct*100,2), exit_reason=reason, score=pos.get("score",0), chart=pos.get("chart_state",""))
                    if pnl_pct < -0.03:
                        relay_bridge.push_warning(symbol=symbol, message=f"Loss exit {pnl_pct:+.1%} [{reason}]", level="caution")


        except Exception as e:
            logger.error(f"Exit check error {symbol}: {e}\n{traceback.format_exc()}")

    return bot_state


def startup(bot_state: Dict) -> Dict:
    """Run startup tasks."""
    logger.info("=== DKTrenchBot v2 Starting ===")
    logger.info(f"Wallet: {BOT_WALLET_ADDRESS}")

    # Reconcile on startup
    try:
        logger.info("Running startup reconcile...")
        reconcile_mod.reconcile(bot_state)
    except Exception as e:
        logger.error(f"Startup reconcile error: {e}")

    # Wallet hygiene on startup
    try:
        logger.info("Running wallet hygiene...")
        wallet_hygiene.run_hygiene(bot_state, force=False)
    except Exception as e:
        logger.error(f"Startup hygiene error: {e}")

    # Run initial token discovery (XRPL-native, 350 token target)
    try:
        import xrpl_amm_discovery as discovery_mod
        logger.info("Running XRPL-native token discovery (target: 350 tokens)...")
        discovered = discovery_mod.run_discovery(force=True)
        logger.info(f"Discovery: {len(discovered)} tokens in active registry")
    except Exception as e:
        logger.warning(f"Startup discovery error (non-fatal): {e}")

    # Start sniper in background
    try:
        def on_sniper_hit(spec):
            logger.info(f"SNIPER: New token discovered: {spec['symbol']} score={spec['sniper_score']}/5")
        sniper_mod.start_sniper_thread(callback=on_sniper_hit)
    except Exception as e:
        logger.warning(f"Sniper start error: {e}")

    return bot_state


def main():
    global _running, _bot_state, _last_report_day

    _bot_state = state_mod.load()
    _bot_state = startup(_bot_state)

    last_reconcile  = time.time()
    last_improve    = _bot_state.get("last_improve", 0)
    last_discovery  = time.time()  # discovery runs every 15 min independently

    logger.info(f"Starting main loop (interval={POLL_INTERVAL_SEC}s)")
    logger.info("Waiting 3s for RPC rate limit to clear after startup...")
    time.sleep(3)

    while _running:
        cycle_start = time.time()

        try:
            _bot_state = run_cycle(_bot_state)

            # ── 8. Reconcile every 30 min ──────────────────────────────────────
            if time.time() - last_reconcile >= 1800:
                try:
                    logger.info("Running periodic reconcile...")
                    reconcile_mod.reconcile(_bot_state)
                    last_reconcile = time.time()
                except Exception as e:
                    logger.error(f"Reconcile error: {e}")

            # ── 8b. Discovery refresh every 10 min ───────────────────────────
            if time.time() - last_discovery >= 600:
                try:
                    import xrpl_amm_discovery as _disc_mod
                    discovered = _disc_mod.run_discovery()
                    logger.info(f"Discovery refresh: {len(discovered)} tokens in registry")
                    last_discovery = time.time()
                except Exception as _de:
                    logger.debug(f"Discovery refresh error: {_de}")

            # ── 9. Improve every 2 hours ──────────────────────────────────────
            if time.time() - _bot_state.get("last_improve", 0) >= 2 * 3600:
                try:
                    logger.info("Running improve analysis...")
                    improve_mod.run_improve(_bot_state)
                except Exception as e:
                    logger.error(f"Improve error: {e}")
                try:
                    import xrpl_amm_discovery as discovery_mod
                    logger.info("Running XRPL-native dynamic token discovery...")
                    discovered = discovery_mod.run_discovery()
                    logger.info(f"Discovery: {len(discovered)} tokens now in active registry")
                    _bot_state["last_improve"] = time.time()
                except Exception as e:
                    logger.error(f"Discovery error: {e}")

            # Daily report
            today = int(time.time() // 86400)
            if today != _last_report_day:
                try:
                    report_mod.generate_report(_bot_state)
                    _last_report_day = today
                    logger.info("Daily report generated")
                except Exception as e:
                    logger.error(f"Report error: {e}")

            _write_status(_cycle_count, len(_bot_state.get("positions", {})))

        except Exception as e:
            logger.error(f"Cycle error: {e}\n{traceback.format_exc()}")
            _write_status(_cycle_count, 0, str(e))

        # Sleep until next cycle
        elapsed = time.time() - cycle_start
        sleep_for = max(0, POLL_INTERVAL_SEC - elapsed)
        logger.info(f"Cycle done in {elapsed:.1f}s — sleeping {sleep_for:.0f}s")

        # Interruptible sleep
        for _ in range(int(sleep_for)):
            if not _running:
                break
            time.sleep(1)

    logger.info("=== Bot stopped cleanly ===")
    state_mod.save(_bot_state)


if __name__ == "__main__":
    main()
