"""
config.py — All tunable parameters for DKTrenchBot v2
Edit this file to tune bot behavior. Do NOT store secrets here.
"""

import os

# ─── Endpoints ────────────────────────────────────────────────────────────────
CLIO_URL = "http://xrpl-rpc.goons.app:51233"
WS_URL   = "ws://xrpl-rpc.goons.app:51238"

# ─── File Paths ───────────────────────────────────────────────────────────────
SECRETS_FILE = os.path.expanduser("/home/agent/workspace/memory/secrets.md")
STATE_DIR    = os.path.join(os.path.dirname(__file__), "state")

# ─── Scoring Thresholds ───────────────────────────────────────────────────────
# DATA AUDIT 2026-04-06:
#   pre_breakout  WR=42%  avg=+113% → primary entry state, catch runners here
#   continuation  WR=17%  avg=-1.4% → DISABLED (bleeder)
#   orphan        WR=14%  avg=-8.5  → DISABLED (rugpull magnet)
#   expansion     WR=0%   1 trade   → insufficient data, disabled
# Score tiers: elite gets full size, normal gets half, small stays disabled
SCORE_ELITE     = 65   # 65+ → elite size (20 XRP) — runners come from here
SCORE_TRADEABLE = 57   # auto: WR=13.7% < 40%
SCORE_SMALL     = 999  # small band DISABLED — 9.5% WR, just bleeds capital

# ─── Chart State Filters ──────────────────────────────────────────────────────
# ONLY pre_breakout proven positive EV. continuation/orphan DISABLED.
CONTINUATION_MIN_SCORE  = 999  # DISABLED — 17% WR avg -1.4 XRP
ORPHAN_MIN_SCORE        = 999  # DISABLED — 14% WR rugpull magnet
PREFERRED_CHART_STATES  = {"pre_breakout"}  # only state with runners

# ─── Risk / Exit Rules ────────────────────────────────────────────────────────
HARD_STOP_PCT        = 0.15   # -15% hard stop — tight enough to cut losers, wide enough to not stop-hunt
HARD_STOP_EARLY_PCT  = 0.10   # -10% in first 30min — meme tokens need room to breathe initially
HARD_STOP_GRACE_SEC  = 1800   # kept for compatibility

# Tokens that have repeatedly triggered hard stops — temporarily skip re-entry
# Learned: Teddy hit hard stop 2x in same session (high supply meme, too volatile)
SKIP_REENTRY_SYMBOLS = {"Teddy", "ZERPS", "JEET"}  # PHX removed — scoring elite+DNA60 in pre_breakout, allow re-entry
TRAIL_STOP_PCT       = 0.20   # -20% trailing from peak
# DATA: best trade +12.8% = TP1 firing immediately, killing runners.
# Meme tokens can 5-50x. Let winners breathe.
TP1_PCT         = 0.20   # +20% → sell 30% — lock early profit, keep 70% running
TP1_SELL_FRAC   = 0.30   # sell 30% at TP1
TP2_PCT         = 0.50   # +50% → sell 30% of remainder — still holding ~49% of original
TP2_SELL_FRAC   = 0.30   # sell 30% at TP2
TP3_PCT         = 3.00   # +300% → sell 30% of remainder — ~34% of original still running free
TP3_SELL_FRAC   = 0.30   # sell 30% at TP3
TP4_PCT         = 6.00   # +600% → full exit — M1N-type runners only get here
STALE_EXIT_HOURS = 3     # cut at 3hr if no meaningful move (was 6hr)
MAX_HOLD_HOURS   = 6     # absolute cap 6hr (was 12hr)

# ─── Position Sizing ──────────────────────────────────────────────────────────
XRP_PER_TRADE_BASE = 10.0   # Normal entry (55–64) — reduced, preserve capital
XRP_ELITE_BASE     = 15.0   # Elite entry (65+) — max size for high-conviction runners
XRP_SMALL_BASE     = 5.0    # Micro/sniper plays — small TVL tokens with high upside
XRP_SNIPER_BASE    = 5.0    # Sniper mode position size
XRP_MICRO_BASE     = 5.0    # Micro-cap new token — small enough to not move the price

# TVL threshold below which we use micro sizing (new/tiny pools like PHX at launch)
TVL_MICRO_CAP_XRP  = 2000   # Under 2000 XRP TVL = micro position (5 XRP) — runners often start small
MAX_POSITIONS = 3   # warden defensive: drawdown alarm

# ─── Safety Filters ───────────────────────────────────────────────────────────
MIN_TVL_XRP          = 300    # minimum 300 XRP TVL — catches early runners, blocks pure ghost pools
MIN_LP_BURN_PCT      = 80
MIN_TVL_DROP_EXIT    = 0.40   # exit immediately if TVL drops >40% in one cycle (pool being drained)
WHALE_XRP_THRESHOLD  = 10000

# ─── Bot Behavior ─────────────────────────────────────────────────────────────
POLL_INTERVAL_SEC = 60

# ─── Black Hole Accounts (for LP burn check) ──────────────────────────────────
BLACK_HOLES = [
    "rrrrrrrrrrrrrrrrrrrrrhoLvTp",
    "rrrrrrrrrrrrrrrrrrrrBZbvji",
]

# ─── Bot Wallet ───────────────────────────────────────────────────────────────
BOT_WALLET_ADDRESS = "rKQACag8Td9TrMxBwYJPGRMDV8cxGfKsmF"
OPERATOR_WALLET    = "rUWWnjZyBsmGPPLirtCf3NbUXJ1amet86e"

# ─── Token Registry ───────────────────────────────────────────────────────────
# Verified live AMM pools on XRPL mainnet
TOKEN_REGISTRY = [
    {"symbol": "FUZZY",  "issuer": "rhCAT4hRdi2Y9puNdkpMzxrdKa5wkppR62"},
    {"symbol": "MAG",    "issuer": "rXmagwMmnFtVet3uL26Q2iwk287SRvVMJ"},
    {"symbol": "XPM",    "issuer": "rXPMxBeefHGxx2K7g5qmmWq3gFsgawkoa"},
    {"symbol": "PHNIX",  "issuer": "rDFXbW2ZZCG5WgPtqwNiA2xZokLMm9ivmN"},
    {"symbol": "PHX",    "issuer": "rskkPc3Eea3phZmzYqdoRFXeHg1GF7oVzG"},
    {"symbol": "ARMY",   "issuer": "rGG3wQ4kUzd7Jnmk1n5NWPZjjut62kCBfC"},
    {"symbol": "EVR",    "issuer": "ra9g3LAJm9xJu8Awe7oWzR6VXFB1mpFtSe"},
    {"symbol": "DROP",   "issuer": "rszenFJoDdiGjyezQc8pME9KWDQH43Tswh"},
    {"symbol": "BEAR",   "issuer": "rBEARGUAsyu7tUw53rufQzFdWmJHpJEqFW"},
    {"symbol": "ATM",    "issuer": "raDZ4t8WPXkmDfJWMLBcNZmmSHmBC523NZ"},
    {"symbol": "CULT",   "issuer": "rCULtAKrKbQjk1Tpmg5hkw4dpcf9S9KCs"},
    {"symbol": "SOLO",   "issuer": "rsoLo2S1kiGeCcn6hCUXVrCpGMWLrRrLZz"},
    {"symbol": "SLT",    "issuer": "rfGCeDUdtbzKbXfgvrpG745qdC1hcZBz8S"},
    {"symbol": "XAH",    "issuer": "rswh1fvyLqHizBS2awu1vs6QcmwTBd9qiv"},
    {"symbol": "FLR",    "issuer": "rcxJwVnftZzXqyH9YheB8TgeiZUhNo1Eu"},
    {"symbol": "BERT",   "issuer": "rpwAnF1mMZRszxdinETFHwzGQiPgsv3jHR"},
    {"symbol": "GOAT",   "issuer": "r96Ny5BTU3z4Aw4BfiMJ7RTgDa5iE17u9t"},
    {"symbol": "CSC",    "issuer": "rCSCManTZ8ME9EoLrSHHYKW8PPwWMgkwr"},
    {"symbol": "XRPH",   "issuer": "rM8hNqA3jRJ5Zgp3Xf3xzdZcx2G37guiZk"},
    {"symbol": "SIGMA",  "issuer": "rfKYWZ84fm9eVEdoTcsQCo1WdqMPyaUF5z"},
    {"symbol": "JELLY",  "issuer": "rKHsxmaqf2SfcyU9LRi3VyjpAtyg6ZrQMp"},
    {"symbol": "CORE",   "issuer": "rcoreNywaoz2ZCQ8Lg2EbSLnGuRBmun6D"},
    {"symbol": "TOTO",   "issuer": "r9sH6YEVRyg8uYaKfyk1EfH36Lfq7a8PUD"},
    {"symbol": "BCHAMP", "issuer": "rhYhn7s6z4HAfuJm7ehuSE7wxepRoUPwpi"},
    {"symbol": "SEAL",   "issuer": "r4pXXQzJ8soYSX4QKeeW4BzRQS1PCtVYLJ"},
    {"symbol": "DONNIE", "issuer": "rhhaVvZF69sQBgiDuM2avL2pbrryT5cGTF"},
    {"symbol": "SGB",    "issuer": "rctArjqVvTHihekzDeecKo6mkTYTUSBNc"},
    {"symbol": "ETH",    "issuer": "rcA8X3TVMST1n3CJeAdGk1RdRCHii7N2h"},
]


def currency_hex(symbol: str) -> str:
    """Convert token symbol to XRPL hex currency code (for symbols > 3 chars)."""
    if len(symbol) <= 3:
        return symbol
    return symbol.encode().hex().upper().ljust(40, '0')


def get_currency(symbol: str) -> str:
    """Return currency code: raw if <= 3 chars, hex if longer."""
    return symbol if len(symbol) <= 3 else currency_hex(symbol)
